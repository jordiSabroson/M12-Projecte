package itic.formulariospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormularioSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
