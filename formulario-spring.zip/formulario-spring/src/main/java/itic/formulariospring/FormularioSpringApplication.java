package itic.formulariospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormularioSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormularioSpringApplication.class, args);
	}

}
