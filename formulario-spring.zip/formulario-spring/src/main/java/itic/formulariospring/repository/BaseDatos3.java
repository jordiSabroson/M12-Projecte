package itic.formulariospring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import itic.formulariospring.bean.Libro;

public interface BaseDatos3 extends JpaRepository<Libro, Integer> {

}
